export declare class MdError extends Error {
    constructor(value: string);
}
