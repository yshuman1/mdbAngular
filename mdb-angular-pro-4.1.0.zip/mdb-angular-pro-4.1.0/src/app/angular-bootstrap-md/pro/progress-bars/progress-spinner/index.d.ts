import { ModuleWithProviders } from '@angular/core';
declare class MdProgressSpinnerModule {
    static forRoot(): ModuleWithProviders;
}
export { MdProgressSpinnerModule };
export * from './progress-spinner';
