export declare class ProgressbarConfig {
    animate: Boolean;
    max: number;
}
