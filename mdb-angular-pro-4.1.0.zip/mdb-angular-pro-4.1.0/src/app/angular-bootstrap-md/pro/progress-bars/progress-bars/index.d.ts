import { ModuleWithProviders } from '@angular/core';
export declare class MdProgressBarModule {
    static forRoot(): ModuleWithProviders;
}
export * from './progress-bar';
