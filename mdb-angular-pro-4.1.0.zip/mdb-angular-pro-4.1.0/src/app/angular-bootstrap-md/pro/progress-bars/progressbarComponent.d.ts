import { ProgressbarConfig } from './progressbarConfig';
export declare class ProgressbarComponent {
    animate: boolean;
    max: number;
    type: string;
    value: number;
    constructor(config: ProgressbarConfig);
}
