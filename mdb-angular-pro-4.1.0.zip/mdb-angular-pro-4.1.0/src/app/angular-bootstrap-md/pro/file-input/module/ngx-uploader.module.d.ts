export declare class NgUploaderModule {
}
