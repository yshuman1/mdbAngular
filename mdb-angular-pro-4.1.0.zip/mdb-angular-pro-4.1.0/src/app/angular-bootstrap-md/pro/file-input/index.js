export * from "./module/ngx-uploader.module";
export * from './classes/ngx-uploader.class';
export * from './directives/ng-file-select.directive';
export * from './directives/ng-file-drop.directive';
//# sourceMappingURL=index.js.map