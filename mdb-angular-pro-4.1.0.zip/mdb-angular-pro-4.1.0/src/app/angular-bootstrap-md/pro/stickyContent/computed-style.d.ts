export declare function computedStyle(element: string | HTMLElement, styleProp: string): string;
