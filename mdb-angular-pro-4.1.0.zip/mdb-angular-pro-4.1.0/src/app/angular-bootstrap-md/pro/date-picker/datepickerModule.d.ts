export declare class MyDatePickerModule {
}
