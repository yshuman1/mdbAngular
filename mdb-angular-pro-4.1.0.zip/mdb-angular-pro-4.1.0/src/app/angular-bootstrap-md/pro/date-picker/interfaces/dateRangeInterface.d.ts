import { IMyDate } from "./dateInterface";
export interface IMyDateRange {
    begin: IMyDate;
    end: IMyDate;
}
