import { IMyDate } from "./dateInterface";
export interface IMyMarkedDates {
    dates: Array<IMyDate>;
    color: string;
}
