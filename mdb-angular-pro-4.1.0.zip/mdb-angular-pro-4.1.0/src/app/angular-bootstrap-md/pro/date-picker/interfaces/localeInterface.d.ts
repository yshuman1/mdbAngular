import { IMyOptions } from "./optionsInterface";
export interface IMyLocales {
    [lang: string]: IMyOptions;
}
