import { IMyOptions } from "../interfaces/index";
export declare class LocaleService {
    private locales;
    getLocaleOptions(locale: string): IMyOptions;
}
