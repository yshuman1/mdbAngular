import { OnInit } from '@angular/core';
export declare class SimpleChartComponent implements OnInit {
    percent: any;
    barColor: string;
    options: any;
    constructor();
    ngOnInit(): void;
}
