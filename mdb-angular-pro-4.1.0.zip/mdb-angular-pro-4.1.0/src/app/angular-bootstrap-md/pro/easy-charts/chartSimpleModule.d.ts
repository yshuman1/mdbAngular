export declare class chartSimpleModule {
}
