export * from './chartSimpleComponent';
export * from './chartSmallpieComponent';
export * from './chartSimpleModule';
