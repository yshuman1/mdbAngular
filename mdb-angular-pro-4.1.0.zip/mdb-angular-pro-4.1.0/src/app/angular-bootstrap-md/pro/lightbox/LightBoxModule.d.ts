export declare class LightBoxModule {
}
