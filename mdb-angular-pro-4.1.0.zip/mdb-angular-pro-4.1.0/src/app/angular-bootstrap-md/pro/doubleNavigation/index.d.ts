import { DoubleNavbar } from './doubleNavbar';
export declare const DOUBLE_NAVBAR_COMPONENTS: typeof DoubleNavbar[];
export declare class DoubleNavbarModule {
}
