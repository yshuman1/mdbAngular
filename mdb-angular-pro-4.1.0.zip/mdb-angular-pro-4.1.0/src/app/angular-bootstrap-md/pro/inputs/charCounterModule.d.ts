import { ModuleWithProviders } from "@angular/core";
export declare class charCounterModule {
    static forRoot(): ModuleWithProviders;
}
