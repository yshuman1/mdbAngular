export declare class CardReveal {
    socials: any;
    show: boolean;
    toggle(): void;
}
