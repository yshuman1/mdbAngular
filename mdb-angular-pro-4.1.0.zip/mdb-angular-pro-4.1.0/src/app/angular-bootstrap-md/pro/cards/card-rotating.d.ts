export declare class CardRotating {
    rotate: boolean;
    toggle(): void;
}
