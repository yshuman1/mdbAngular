import { SBItem } from './sb-item';
export declare class SBItemHead {
    private sbItem;
    constructor(sbItem: SBItem);
    toggleClick(event: any): void;
}
