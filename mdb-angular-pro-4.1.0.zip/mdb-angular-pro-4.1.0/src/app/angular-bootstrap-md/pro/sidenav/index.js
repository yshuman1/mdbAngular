export * from './sidenavComponent';
export * from './sidenavModule';
//# sourceMappingURL=index.js.map