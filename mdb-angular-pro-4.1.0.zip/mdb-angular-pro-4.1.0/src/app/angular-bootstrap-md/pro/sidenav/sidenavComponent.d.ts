export declare class SidenavComponent {
    sidenavClass: any;
    slideInState: string;
    isActive: boolean;
    collapse(): void;
    backdrop(): void;
}
