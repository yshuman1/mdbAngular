export declare type NG_SPINNING_PRELOADER_TYPE = Element | HTMLDivElement;
