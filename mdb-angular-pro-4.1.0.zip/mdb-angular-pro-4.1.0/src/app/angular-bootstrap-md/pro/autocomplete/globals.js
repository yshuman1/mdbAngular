export var MAX_CHARS = 524288;
export var MIN_SEARCH_LENGTH = 3;
export var PAUSE = 100;
export var TEXT_SEARCHING = "Searching...";
export var TEXT_NO_RESULTS = "No results found";
export var CLEAR_TIMEOUT = 50;
export function isNil(value) {
    return typeof value === "undefined" || value === null;
}
;
//# sourceMappingURL=globals.js.map