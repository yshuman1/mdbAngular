export declare class Ng2CompleterModule {
}
