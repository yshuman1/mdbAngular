;
//# sourceMappingURL=completerItemComponent.js.map