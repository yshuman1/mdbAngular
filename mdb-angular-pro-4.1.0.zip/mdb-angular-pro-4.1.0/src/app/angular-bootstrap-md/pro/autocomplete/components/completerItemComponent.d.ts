export interface CompleterItem {
    title: string;
    description?: string;
    image?: string;
    originalObject: any;
}
