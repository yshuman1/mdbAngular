export declare class OverlayContainer {
    private _containerElement;
    getContainerElement(): HTMLElement;
    private _createContainer();
}
