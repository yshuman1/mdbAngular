export * from './optionInterface';
export * from './selectComponent';
export declare class SelectModule {
}
