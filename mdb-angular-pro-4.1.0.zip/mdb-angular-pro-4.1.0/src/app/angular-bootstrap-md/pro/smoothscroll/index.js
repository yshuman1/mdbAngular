export * from './ng2-page-scroll.directive';
export * from './ng2-page-scroll.service';
export * from './ng2-page-scroll-config';
export * from './ng2-page-scroll-instance';
export * from './ng2-page-scroll-util.service';
export { Ng2PageScrollModule } from './ng2-page-scroll.module';
//# sourceMappingURL=index.js.map