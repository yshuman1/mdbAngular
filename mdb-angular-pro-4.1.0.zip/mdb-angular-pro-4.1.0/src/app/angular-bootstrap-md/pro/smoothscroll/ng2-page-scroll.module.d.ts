import { ModuleWithProviders } from '@angular/core';
export declare class Ng2PageScrollModule {
    static forRoot(): ModuleWithProviders;
}
