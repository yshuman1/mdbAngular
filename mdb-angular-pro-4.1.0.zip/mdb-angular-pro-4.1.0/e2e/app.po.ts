import { browser, element, by } from 'protractor';

export class AngularBootstrapMdQuickstartPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('app-root h1')).getText();
  }
}
